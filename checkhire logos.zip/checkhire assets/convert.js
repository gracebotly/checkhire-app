const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const dir = __dirname;
const svgDir = path.join(dir, 'svg');
const pngDir = path.join(dir, 'png');
const icoDir = path.join(dir, 'ico');

// Ensure output folders exist
[pngDir, icoDir].forEach(d => fs.mkdirSync(d, { recursive: true }));

async function main() {
  const conversions = [
    { src: 'logo-icon-color.svg', out: 'favicon-16.png', w: 16, h: 16 },
    { src: 'logo-icon-color.svg', out: 'favicon-32.png', w: 32, h: 32 },
    { src: 'logo-icon-color.svg', out: 'favicon-48.png', w: 48, h: 48 },
    { src: 'logo-icon-color.svg', out: 'apple-touch-icon.png', w: 180, h: 180 },
    { src: 'logo-icon-color.svg', out: 'icon-192.png', w: 192, h: 192 },
    { src: 'logo-icon-color.svg', out: 'icon-512.png', w: 512, h: 512 },
    { src: 'logo-icon-color.svg', out: 'og-icon.png', w: 1200, h: 1200 },
    { src: 'logo-full-color.svg', out: 'email-header.png', w: 560, h: 160 },
    { src: 'logo-full-color.svg', out: 'email-header@2x.png', w: 1120, h: 320 },
    { src: 'og-default.svg', out: 'og-default.png', w: 1200, h: 630, flatten: true },
  ];

  for (const { src, out, w, h, flatten } of conversions) {
    const svgBuffer = fs.readFileSync(path.join(svgDir, src));
    let pipeline = sharp(svgBuffer).resize(w, h, {
      fit: 'contain',
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    });
    if (flatten) {
      pipeline = pipeline.flatten({ background: { r: 255, g: 255, b: 255 } });
    }
    await pipeline.png().toFile(path.join(pngDir, out));
    console.log(`wrote png/${out} (${w}x${h})`);
  }

  // ICO — build manually since png-to-ico can be unreliable
  try {
    const pngFiles = ['favicon-16.png', 'favicon-32.png'];
    const pngBuffers = pngFiles.map(f => fs.readFileSync(path.join(pngDir, f)));
    const sizes = [16, 32];

    const numImages = pngBuffers.length;
    const headerSize = 6;
    const entrySize = 16;
    const dataOffset = headerSize + entrySize * numImages;

    const header = Buffer.alloc(headerSize);
    header.writeUInt16LE(0, 0);
    header.writeUInt16LE(1, 2);
    header.writeUInt16LE(numImages, 4);

    const entries = [];
    let offset = dataOffset;
    for (let i = 0; i < numImages; i++) {
      const entry = Buffer.alloc(entrySize);
      const s = sizes[i];
      entry.writeUInt8(s < 256 ? s : 0, 0);
      entry.writeUInt8(s < 256 ? s : 0, 1);
      entry.writeUInt8(0, 2);
      entry.writeUInt8(0, 3);
      entry.writeUInt16LE(1, 4);
      entry.writeUInt16LE(32, 6);
      entry.writeUInt32LE(pngBuffers[i].length, 8);
      entry.writeUInt32LE(offset, 12);
      entries.push(entry);
      offset += pngBuffers[i].length;
    }

    const ico = Buffer.concat([header, ...entries, ...pngBuffers]);
    fs.writeFileSync(path.join(icoDir, 'favicon.ico'), ico);
    console.log('wrote ico/favicon.ico');
  } catch (err) {
    console.warn('Warning: favicon.ico generation failed:', err.message);
  }

  console.log('\nDone — all PNG/ICO assets generated.');
}

main().catch(console.error);

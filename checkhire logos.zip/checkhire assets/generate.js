const fs = require('fs');
const path = require('path');

// Brand constants
const TEAL = '#1A7A6D';
const WHITE = '#FFFFFF';
const DARK = '#0F172A';
const MUTED = '#475569';
const FONT = "'Plus Jakarta Sans', 'Geist', sans-serif";

// Monogram paths (C + H-with-checkmark) for a given stroke color, at 80x80 scale
function monogramPaths(stroke) {
  return [
    `<path d="M28 22 Q16 22, 16 38 Q16 54, 28 54" fill="none" stroke="${stroke}" stroke-width="4.5" stroke-linecap="round"/>`,
    `<path d="M40 48 L47 56 L47 22" fill="none" stroke="${stroke}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>`,
    `<line x1="62" y1="22" x2="62" y2="56" stroke="${stroke}" stroke-width="4.5" stroke-linecap="round"/>`,
    `<line x1="47" y1="38" x2="62" y2="38" stroke="${stroke}" stroke-width="4.5" stroke-linecap="round"/>`,
  ].join('\n  ');
}

// Full icon (rounded rect + monogram) at 80x80
function icon80(bg, stroke) {
  return `<rect x="0" y="0" width="80" height="80" rx="16" fill="${bg}"/>
  ${monogramPaths(stroke)}`;
}

// Wordmark tspan helper
function wordmark(opts = {}) {
  const { x = 0, y = 30, fontSize = 28, checkColor = DARK, hireColor = TEAL, anchor = '' } = opts;
  const anchorAttr = anchor ? ` text-anchor="${anchor}"` : '';
  return `<text x="${x}" y="${y}" font-family="${FONT}" font-size="${fontSize}" font-weight="700" letter-spacing="-0.5"${anchorAttr}><tspan fill="${checkColor}">Check</tspan><tspan fill="${hireColor}">Hire</tspan></text>`;
}

const files = {};

// 1. logo-icon-color.svg
files['logo-icon-color.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="80" height="80">
  ${icon80(TEAL, WHITE)}
</svg>`;

// 2. logo-icon-white.svg
files['logo-icon-white.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="80" height="80">
  ${icon80(WHITE, TEAL)}
</svg>`;

// 3. logo-icon-dark.svg
files['logo-icon-dark.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="80" height="80">
  ${icon80(DARK, WHITE)}
</svg>`;

// 4. logo-full-color.svg
files['logo-full-color.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 80" width="300" height="80">
  ${icon80(TEAL, WHITE)}
  ${wordmark({ x: 96, y: 50, fontSize: 28 })}
</svg>`;

// 5. logo-full-white.svg
files['logo-full-white.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 80" width="300" height="80">
  <rect x="0" y="0" width="80" height="80" rx="16" fill="rgba(255,255,255,0.15)"/>
  ${monogramPaths(WHITE)}
  ${wordmark({ x: 96, y: 50, fontSize: 28, checkColor: WHITE, hireColor: WHITE })}
</svg>`;

// 6. logo-stacked-color.svg
files['logo-stacked-color.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 130" width="200" height="130">
  <g transform="translate(60, 0)">
    ${icon80(TEAL, WHITE)}
  </g>
  ${wordmark({ x: 100, y: 115, fontSize: 28, anchor: 'middle' })}
</svg>`;

// 7. logo-wordmark-color.svg
files['logo-wordmark-color.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 40" width="200" height="40">
  ${wordmark({ x: 0, y: 30, fontSize: 28 })}
</svg>`;

// 8. logo-wordmark-white.svg
files['logo-wordmark-white.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 40" width="200" height="40">
  ${wordmark({ x: 0, y: 30, fontSize: 28, checkColor: WHITE, hireColor: WHITE })}
</svg>`;

// 9. logo-full-tagline.svg — smaller 64x64 icon with 0.8x scaled monogram
function monogramPaths08(stroke) {
  // Scale 0.8x from 80x80: multiply all coords by 0.8
  return [
    `<path d="M22.4 17.6 Q12.8 17.6, 12.8 30.4 Q12.8 43.2, 22.4 43.2" fill="none" stroke="${stroke}" stroke-width="3.6" stroke-linecap="round"/>`,
    `<path d="M32 38.4 L37.6 44.8 L37.6 17.6" fill="none" stroke="${stroke}" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>`,
    `<line x1="49.6" y1="17.6" x2="49.6" y2="44.8" stroke="${stroke}" stroke-width="3.6" stroke-linecap="round"/>`,
    `<line x1="37.6" y1="30.4" x2="49.6" y2="30.4" stroke="${stroke}" stroke-width="3.6" stroke-linecap="round"/>`,
  ].join('\n    ');
}

files['logo-full-tagline.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 380 90" width="380" height="90">
  <g transform="translate(0, 5)">
    <rect x="0" y="0" width="64" height="64" rx="13" fill="${TEAL}"/>
    ${monogramPaths08(WHITE)}
  </g>
  ${wordmark({ x: 80, y: 32, fontSize: 28 })}
  <text x="80" y="55" font-family="${FONT}" font-size="12" font-weight="400" fill="${MUTED}">Work with anyone online — without the risk.</text>
</svg>`;

// 10. og-default.svg — 1200x630 social preview
function monogramPaths125(stroke) {
  // Scale 1.25x from 80x80
  return [
    `<path d="M35 27.5 Q20 27.5, 20 47.5 Q20 67.5, 35 67.5" fill="none" stroke="${stroke}" stroke-width="5.625" stroke-linecap="round"/>`,
    `<path d="M50 60 L58.75 70 L58.75 27.5" fill="none" stroke="${stroke}" stroke-width="5.625" stroke-linecap="round" stroke-linejoin="round"/>`,
    `<line x1="77.5" y1="27.5" x2="77.5" y2="70" stroke="${stroke}" stroke-width="5.625" stroke-linecap="round"/>`,
    `<line x1="58.75" y1="47.5" x2="77.5" y2="47.5" stroke="${stroke}" stroke-width="5.625" stroke-linecap="round"/>`,
  ].join('\n    ');
}

files['og-default.svg'] = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630">
  <rect x="0" y="0" width="1200" height="630" fill="${WHITE}"/>
  <g transform="translate(415, 180)">
    <rect x="0" y="0" width="100" height="100" rx="20" fill="${TEAL}"/>
    ${monogramPaths125(WHITE)}
  </g>
  <text x="535" y="250" font-family="${FONT}" font-size="48" font-weight="700" letter-spacing="-1"><tspan fill="${DARK}">Check</tspan><tspan fill="${TEAL}">Hire</tspan></text>
  <text x="600" y="350" font-family="${FONT}" font-size="20" font-weight="400" fill="${MUTED}" text-anchor="middle">Work with anyone online — without the risk.</text>
  <line x1="450" y1="380" x2="750" y2="380" stroke="#E0F5EF" stroke-width="1"/>
  <text x="600" y="410" font-family="${FONT}" font-size="14" font-weight="500" fill="${MUTED}" text-anchor="middle">checkhire.co</text>
</svg>`;

// Write all files into svg/ folder
const svgDir = path.join(__dirname, 'svg');
fs.mkdirSync(svgDir, { recursive: true });
for (const [filename, content] of Object.entries(files)) {
  const filepath = path.join(svgDir, filename);
  fs.writeFileSync(filepath, content, 'utf8');
  console.log(`wrote svg/${filename}`);
}

console.log(`\nDone — ${Object.keys(files).length} SVG files generated.`);
